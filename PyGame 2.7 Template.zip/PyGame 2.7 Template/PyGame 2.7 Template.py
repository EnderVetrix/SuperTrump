#thanks to sentdex on Youtube.com for Pygame basics tutorials              
import pygame
import pyganim
import sys
import time
import winsound
from pygame.locals import *
from types import MethodType
import itertools

pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.mixer.init()
pygame.init()

#init sounds e.g. "sound = pygame.mixer.Sound('sound.wav')"

#if game starts in fullscreen,
        ##setDisplay = pygame.display.set_mode((640,480),FULLSCREEN)
        ##pygame.mouse.set_visible(0)
#else
setDisplay = pygame.display.set_mode((640,480))
pygame.display.set_caption('Game Name')

#button state inits
global RDOWN, LDOWN, UDOWN, DDOWN
RDOWN = 0
LDOWN = 0
UDOWN = 0
DDOWN = 0
#use LPRESS, etc. for momentary flags upon button press
#use LUP, etc. for momentary flags upon button release

#entire game init define
def reset():
        pygame.mixer.stop()
        #globalize all changed variables
#end reset

#set up frames per second
FPS = 30
fpsTime = pygame.time.Clock()

#checkEvent for button inputs and such
def checkEvent():
        global LDOWN
        global RDOWN
        global UDOWN
        global DDOWN
        global PAUSE
        for event in pygame.event.get():
                #'print event' for diagnostic crap
                if event.type == QUIT:
                        pygame.quit()
                        sys.exit()
                if event.type == KEYDOWN:
                        if event.key == K_LEFT:
                                LDOWN = 1
                                #use LPRESS, etc. for momentary flags upon button press
                        if event.key == K_RIGHT:
                                RDOWN = 1
                        if event.key == K_UP:
                                UDOWN = 1
                        if event.key == K_DOWN:
                                DDOWN = 1
                                DPRESS = 1
##                        if event.key == K_z:
##                                ZDOWN = 1
##                                ZUP = 0
                        if event.key == K_ESCAPE:
                                pygame.mixer.stop()
                                pygame.quit()
                                sys.exit()
                if event.type == KEYUP:
                        if event.key == K_LEFT:
                                LDOWN = 0
                                #use LUP, etc. for momentary flags upon button release
                        if event.key == K_RIGHT:
                                RDOWN = 0
                        if event.key == K_UP:
                                UDOWN = 0
                        if event.key == K_DOWN:
                                DDOWN = 0
#end checkEvent
                                
#sprite
class sprite(object):
        def _init_(self,sx,sy,swidth,sheight,simage):
                self.x = sx
                self.y = sy
                self.image = pyganim.PygAnimation([(simage)])
                self.dimensions = [swidth,sheight]
                self.width = swidth
                self.height = sheight
                self.yspeed = 10
                self.xspeed = 10
                self.ymovement = 'none'
                self.xmovement = 'none'
        #checkCollide function. Use like: if whatever.checkCollide(object): code here
        def checkCollide(self, obj):
                state = 0
                selfdimensions = [self.width,self.height]
                objdimensions = [obj.width,obj.height]
                selfbottom = (self.y + self.yoffset) + selfdimensions[1]
                selfright = (self.x + self.woffset) + selfdimensions[0]
                selfleft = self.x + self.woffset
                selftop = self.y + self.yoffset
                objbottom = (obj.y + obj.yoffset) + objdimensions[1]
                objright = (obj.x + obj.woffset) + objdimensions[0]
                objleft = obj.x + obj.woffset
                objtop = obj.y + obj.yoffset
                if selfright > objleft and selfbottom > objtop and selfleft < objright and selftop < objbottom:
                        state = 1
                return state
        
        def update(self):
                self.image.blit(setDisplay,(self.x,self.y))
#end sprite
                                
reset()

#gameloop
while 1:
        setDisplay.fill((0,0,0))
        checkEvent()

        #handle frame-to-frame events here
        
        pygame.display.update()
        fpsTime.tick(FPS)
quit

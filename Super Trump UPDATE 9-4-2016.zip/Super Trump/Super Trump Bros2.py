#thanks to sentdex on Youtube.com for Pygame basics tutorials              
import pygame
import pyganim
import sys
import time
import winsound
from pygame.locals import *
from types import MethodType
import itertools

pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.mixer.init()
pygame.init()

#init sounds e.g. "sound = pygame.mixer.Sound('sound.wav')"


#if game starts in fullscreen,
##setDisplay = pygame.display.set_mode((640,480),FULLSCREEN)
##pygame.mouse.set_visible(0)
#else
setDisplay = pygame.display.set_mode((640,480))


pygame.display.set_caption('Super Trump Bros')

#button state inits
global RDOWN, LDOWN, UDOWN, DDOWN, SBDOWN
RDOWN = 0
LDOWN = 0
UDOWN = 0
DDOWN = 0
SBDOWN = 0
#use LPRESS, etc. for momentary flags upon button press
#use LUP, etc. for momentary flags upon button release

#entire game init define
def reset():
        pygame.mixer.stop()
        #globalize all changed variables
        global Trump
        global Blocks
        global Walls
        Trump = Mario()
        Trump._init_(32,(480-64),16,32,"assets\sprites\player\Trump.png",1,3)
        Trump.inAir = 0
        Blocks = [Block(),Block(),Block(),Block(),Block(),Block(),Block(),Block(),Block(),Block()]
        Walls = [Block(),Block(),Block(),Block(),Block(),Block(),Block(),Block(),Block(),Block(),Block(),Block()]
        for i in range(len(Walls)):
            Walls[i]._init_(80,480-((i+8)*16),16,16,"assets/sprites/block/platform-top.png",0,1)
            Walls[i].image.play()
        for i in range(len(Blocks)):
            Blocks[i]._init_(i*16,480-32,16,16,"assets/sprites/block/platform-top.png",0,1)
            Blocks[i].image.play()
        
#end reset

#set up frames per second
FPS = 30
fpsTime = pygame.time.Clock()

#checkEvent for button inputs and such
def checkEvent():
        global LDOWN
        global RDOWN
        global UDOWN
        global DDOWN
        global SBDOWN
        global PAUSE
        for event in pygame.event.get():
                #'print event' for diagnostic crap
                if event.type == QUIT:
                        pygame.quit()
                        sys.exit()
                if event.type == KEYDOWN:
                        if event.key == K_LEFT:
                                LDOWN = 1
                                #use LPRESS, etc. for momentary flags upon button press
                        if event.key == K_RIGHT:
                                RDOWN = 1
                        if event.key == K_UP:
                                UDOWN = 1
                        if event.key == K_DOWN:
                                DDOWN = 1
                                DPRESS = 1
                        if event.key == K_SPACE:
                                SBDOWN = 1
                        if event.key == K_r:
                                reset()
##                        if event.key == K_z:
##                                ZDOWN = 1
##                                ZUP = 0
                        if event.key == K_ESCAPE:
                                pygame.mixer.stop()
                                pygame.quit()
                                sys.exit()
                if event.type == KEYUP:
                        if event.key == K_LEFT:
                                LDOWN = 0
                                #use LUP, etc. for momentary flags upon button release
                        if event.key == K_RIGHT:
                                RDOWN = 0
                        if event.key == K_UP:
                                UDOWN = 0
                        if event.key == K_DOWN:
                                DDOWN = 0
                        if event.key == K_SPACE:
                                SBDOWN = 0
#end checkEvent
                                
#start Sprite
class Sprite(object):
        def _init_(self,sx,sy,swidth,sheight,simage):
                self.pos = [sx, sy]
                self.image = pyganim.PygAnimation([(simage,1)])
                self.dimensions = [swidth,sheight]
                self.speed = [10,10]
                self.movement = ['none','none']
        #checkCollide function. Use like: if whatever.checkCollide(object): code here
        def checkCollide(self, obj):
                state = 0
                                
                selfbottom = self.pos[1] + self.dimensions[1]
                selfright = self.pos[0] + self.dimensions[0]
                selfleft = self.pos[0]
                selftop = self.pos[1]
                
                objbottom = obj.pos[1] + obj.dimensions[1]
                objright = obj.pos[0] + obj.dimensions[0]
                objleft = obj.pos[0]
                objtop = obj.pos[1]
                
                if selfright > objleft and selfbottom > objtop and selfleft < objright and selftop < objbottom:
                        state = 1
                return state
        
        def update(self):
                self.image.blit(setDisplay,(self.pos[0],self.pos[1]))
#end Sprite

#start Mario
class Mario(Sprite):
        def _init_(self,sx,sy,swidth,sheight,simage,stat,live):
                #x and y position
                self.pos = [sx, sy]
                #image dimensions and image animation
                self.dimensions = [swidth,sheight]
                self.image = pyganim.PygAnimation([(simage, 1)])
                self.image.play()
                #correct the imcompetant spawner by rounding his outrageous number to an appropriate value
                if stat > 4:
                        self.state = 4
                elif stat < 0:
                        self.state = 0
                else:
                        self.state = stat
                #amount of cash money collected (displayed in-game)
                self.coins = 0

                #lives
                self.lives = live
                
                #airborne or no?
                self.inAir = 0

                #potential momentum in a specific direction
                self.delta = [0,0]

                #VERY IMPORTANT outer shield for detecting if mario is on the floor or directly against a wall
                self.buffer = [Sprite(),Sprite(),Sprite(),Sprite()]
                #I give the buffers images to better see them
                self.buffer[0]._init_(self.pos[0] - 1,self.pos[1],1,32,'assets\sprites\player/bufferL.png')
                self.buffer[1]._init_(self.pos[0] + 16,self.pos[1],1,32,'assets\sprites\player/bufferR.png')
                self.buffer[2]._init_(self.pos[0],self.pos[1] -1,16,1,'assets\sprites\player/bufferU.png')
                self.buffer[3]._init_(self.pos[0],self.pos[1] +32,16,1,'assets\sprites\player/bufferD.png')
                for i in range(len(self.buffer)):
                    self.buffer[i].image.play()
                
        def move(self):
                #give mario's momentum some rightness
                if RDOWN:
                        if self.delta[0] < 8:
                                self.delta[0] += 4
                #subtract from rightness and give some leftness
                if LDOWN:
                        if self.delta[0] > -8:
                                self.delta[0] -= 4
                #slow momentum down
                
                skid = 2
                if self.delta[0] < 0:
                    self.delta[0] += skid
                if self.delta[0] > 0:
                    self.delta[0] -= skid
                #apply speed to actual position
                self.pos[0] += self.delta[0]

        def jump(self):
                if self.pos[1] > 480:
                        self.state = 0
                #if in air, gravity happens
                if self.inAir:
                        self.delta[1] += 1
                #if on ground, you're good
                if self.inAir == 0:
                        self.delta[1] = 0
                #if pressing space, jump momentum and in air
                if SBDOWN and self.inAir == 0:
                        self.inAir = 1
                        global SBDOWN
                        SBDOWN = 0
                        self.delta[1] = -16
                #apply changes? |apply|/|ok|
                self.pos[1] += self.delta[1]
                
        def collide(self,obj,thing):
##                #enemy collision
##                if thing == 'enemy':
##                        #if colliding with goomba that has not been killed,
##                        if self.checkCollide(obj) and obj.type == 0 and obj.state != 0:
##                                #if player's lower half is higher than goomba's head
##                                if self.pos[1] + 24 < obj.y:
##                                        #kill goomba and give jump boost
##                                        self.kill(obj)
##                                        self.delta[1] -= 25
##                                #if player's lower half is lower than goomba's head, damage ensues
##                                elif self.pos[1] + 24 > obj.y:
##                                        self.state -= 1
##                                        if self.state <= 0:
##                                                self.die()
##                        #if colliding with koopa,
##                        elif self.checkCollide(obj) and obj.type >= 1:
##                                #if lower half is higher, turn koopa into shell
##                                if self.pos[1] + 24 < obj.y:
##                                        obj.state = 1
##                                        self.delta[1] -= 25
##                                #otherwise, d-d-d-d-damage
##                                else:
##                                        self.state -= 1
##                                        if self.state <= 0:
##                                                self.die()



                #BLOCK COLLISION MY GOODNESS
                #O (amount of pixels away from block the player is before they collide * 4)
                if thing == 'block':
                        #if the player is colliding with a solid block
                        if self.checkCollide(obj) and obj.type < 4:
                            #rewind the position of the previous frame
                            self.pos[0] -= self.delta[0]
                            self.pos[1] -= self.delta[1]
                            #align the buffer sprites with the player
                            self.buffer[0].pos = [self.pos[0] - 1, self.pos[1]]
                            self.buffer[1].pos = [self.pos[0] + 16, self.pos[1]]
                            self.buffer[2].pos = [self.pos[0],self.pos[1] - 1]
                            self.buffer[3].pos = [self.pos[0],self.pos[1] + 32]
                            #set up the movement direction for correcting collision
                            if self.delta[1] > 0: movey = 1
                            elif self.delta[1] < 0: movey = -1
                            else: movey = 0

                            if self.delta[0] > 0 :movex = 1
                            elif self.delta[0] < 0 :movex = -1
                            else: movex = 0
                            
                            
                            
                            
                            state = 0
                            #while state is zero, continue these actions:
                            while state == 0:
                                #check whether any buffer has collided with the wall
                                for i in range(len(self.buffer)):
                                        
                                        if self.buffer[i].checkCollide(obj):
                                                #if horizontal buffer collides, cancel x speed and assume y buffers have not collided; y speed will continue
                                                if i == 0 or i == 1:
                                                        self.delta[0] = 0
                        
                                                        #this line makes sure speed is re-added only once
                                                        if state == 0:
                                                                self.pos[1] += self.delta[1]
                                                        state = 1
                                                #if vertical buffer collides, cancel y speed and add delta x to x position, resuming the x motion. If x collision has already been triggered and delta x reset to 0, nothing will be added
                                                elif i == 2 or i == 3:
                                                        self.delta[1] = 0
                                                        #this line makes sure speed is re-added only once
                                                        if state == 0:
                                                                self.pos[0] += self.delta[0]
                                                        state = 1
                                #if no collision, move player forward by 1 pixel on each axis and then realign the positions of the buffers
                                if state == 0:
                                        self.pos[0] += movex
                                        self.pos[1] += movey
                                        self.buffer[0].pos = [self.pos[0] - 1,self.pos[1]]
                                        self.buffer[1].pos = [self.pos[0] + 16,self.pos[1]]
                                        self.buffer[2].pos = [self.pos[0],self.pos[1] - 1]
                                        self.buffer[3].pos = [self.pos[0],self.pos[1] + 32]
                                #sets player's inAir state to 0 if recovered from floor collision
                                if state == 1:
                                        if self.buffer[3].checkCollide(obj):
                                                self.inAir = 0
                                #print self.delta
                            #for use with large lists of blocks. if state is one, break the "for" loop
                            return state
        #end collide
                
        def die(self):
                self.lives -= 1
                if self.lives == -1:
                        global GAMEOVER
                        GAMEOVER = 1
                elif self.state == 0:
                        self.pos = [32,(480-64)]
                        self.inAir = 0
                        self.state = 1
                        self.coins = 0
                        #reset enemies and blocks
        def kill(self,obj):
                obj.state = 0
                
        def update(self):
                for i in range(len(self.buffer)):
                    self.buffer[i].image.blit(setDisplay,(self.buffer[i].pos[0],self.buffer[i].pos[1]))
                self.image.blit(setDisplay,(self.pos[0],self.pos[1]))
        def main(self):
                self.move()
                self.jump()
                for i in range(len(Blocks)):
                    self.collide(Blocks[i],"block")
                for i in range(len(Walls)):
                    self.collide(Walls[i],"block")
                self.die()
                #self.kill()
                self.update()               
                
#end Mario
#start Enemy
class Enemy(Sprite):
        def _init_(self,sx,sy,swidth,sheight,simage,typ,stat):
                self.pos = [sx, sy]
                
                self.image = pyganim.PygAnimation([(simage)])
                self.dimensions = [swidth,sheight]
                
                self.speed = [10,10]
                
                self.type = typ
                self.state = stat
                self.inAir = 0
                self.direction = 'l'
                
                self.buffer = [Sprite(),Sprite(),Sprite(),Sprite()]
                self.buffer[0]._init_(self.pos[0] - 1,self.pos[1],1,32,'assets\sprites\player/bufferL.png')
                self.buffer[1]._init_(self.pos[0] + 16,self.pos[1],1,32,'assets\sprites\player/bufferR.png')
                self.buffer[2]._init_(self.pos[0],self.pos[1] -1,16,1,'assets\sprites\player/bufferU.png')
                self.buffer[3]._init_(self.pos[0],self.pos[1] +32,16,1,'assets\sprites\player/bufferD.png')

        def move(self):
                if self.direction == 'l':
                        self.pos[0] -= self.speed[0]
                else:
                        self.pos[0] += self.speed[0]
        def collide(wall):
                #may need retooling depending on if glitches occur
                if self.buffer[1].checkCollide(wall):
                        self.direction == "l"
                elif self.buffer[1].checkCollide(wall) == 0 and self.buffer[0].checkCollide(wall):
                        self.direction == "r"
                if self.buffer[3].checkCollide(wall) and self.inAir == 1:
                        self.pos[1] = wall.pos[1] - self.dimensions[1]
                        self.inAir = 0
        def die():
                if self.state == 0:
                        self.speed = [0,0]
                        self.pos = [0-self.dimensions[0],0-self.dimensions[1]]
        def main():
            self.move()
            #self.collide()
            self.die()
#end Enemy
#start Block
class Block(Sprite):
    def _init_(self,sx,sy,swidth,sheight,simage,typ,stat):
                self.pos = [sx, sy]
                
                self.image = pyganim.PygAnimation([(simage, 1)])
                self.dimensions = [swidth,sheight]
                
                self.speed = [10,10]
                
                self.type = typ
                self.state = stat
                self.inAir = 0
                self.direction = 'r'
                
                self.buffer = [Sprite(),Sprite(),Sprite(),Sprite()]
                self.buffer[0]._init_(self.pos[0] - 1,self.pos[1],1,32,'assets\sprites\player/bufferL.png')
                self.buffer[1]._init_(self.pos[0] + 16,self.pos[1],1,32,'assets\sprites\player/bufferR.png')
                self.buffer[2]._init_(self.pos[0],self.pos[1] -1,16,1,'assets\sprites\player/bufferU.png')
                self.buffer[3]._init_(self.pos[0],self.pos[1] +32,16,1,'assets\sprites\player/bufferD.png')

                self.spring = 0

    def move(self):
        if self.type > 3:
            hi = 1
            #code n'stuf 
    def collide(self):
        if self.type > 3:
            hi = 2
            #code n'stuf
    def morph(self,obj):
        if self.type > 3:
            hi = 3
            #code n'stuf
    def main(self):
        self.move()
        #self.collide()
        #self.morph()
        self.update()
#end Block
reset()

#gameloop
while 1:
        setDisplay.fill((92,148,252))
        checkEvent()
        for i in range(len(Blocks)):
            Blocks[i].main()
        for i in range(len(Walls)):
            Walls[i].main()
        Trump.main()
        
        #handle frame-to-frame events here
        
        pygame.display.update()
        fpsTime.tick(FPS)
quit

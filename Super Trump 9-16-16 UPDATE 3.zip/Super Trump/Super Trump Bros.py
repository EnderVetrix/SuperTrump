#thanks to sentdex on Youtube.com for Pygame basics tutorials              
import pygame
import pyganim
import sys
import time
import winsound
from pygame.locals import *
from types import MethodType
import itertools

pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.mixer.init()
pygame.init()

#init sounds e.g. "sound = pygame.mixer.Sound('sound.wav')"
overworld = pygame.mixer.Sound('assets/music/overworld.wav')
overworld.set_volume(0.4)
ending = pygame.mixer.Sound("assets/sounds/ending.wav")
bump = pygame.mixer.Sound("assets/sounds/bump.wav")


#if game starts in fullscreen,
##setDisplay = pygame.display.set_mode((640,480),FULLSCREEN)
##pygame.mouse.set_visible(0)
#else
setDisplay = pygame.display.set_mode((640,480))


pygame.display.set_caption('Super Trump Bros')

#button state inits
global RDOWN, LDOWN, UDOWN, DDOWN, SBDOWN, SBPRESS, GAMEOVER, WIN, ENDTIMER, Flaggy
RDOWN = 0
LDOWN = 0
UDOWN = 0
DDOWN = 0
SBDOWN = 0
SBPRESS = 0
GAMEOVER = 0
WIN = 0
ENDTIMER = 0
#use LPRESS, etc. for momentary flags upon button press
#use LUP, etc. for momentary flags upon button release

#set up frames per second
FPS = 30
fpsTime = pygame.time.Clock()

#checkEvent for button inputs and such
def checkEvent():
        global LDOWN
        global RDOWN
        global UDOWN
        global DDOWN
        global SBDOWN
        global SBPRESS
        global PAUSE
        for event in pygame.event.get():
                #'print event' for diagnostic crap
                
                if event.type == QUIT:
                        pygame.mixer.stop()
                        pygame.quit()
                        sys.exit()
                if event.type == KEYDOWN:
                        if event.key == K_LEFT:
                                LDOWN = 1
                                #use LPRESS, etc. for momentary flags upon button press
                        if event.key == K_RIGHT:
                                RDOWN = 1
                        if event.key == K_UP:
                                UDOWN = 1
                        if event.key == K_DOWN:
                                DDOWN = 1
                                DPRESS = 1
                        if event.key == K_SPACE:
                                SBDOWN = 1
                                SBPRESS = 1
                        if event.key == K_r:
                                reset()
##                        if event.key == K_z:
##                                ZDOWN = 1
##                                ZUP = 0
                        if event.key == K_ESCAPE:
                                pygame.mixer.stop()
                                pygame.quit()
                                sys.exit()
                if event.type == KEYUP:
                        if event.key == K_LEFT:
                                LDOWN = 0
                                #use LUP, etc. for momentary flags upon button release
                        if event.key == K_RIGHT:
                                RDOWN = 0
                        if event.key == K_UP:
                                UDOWN = 0
                        if event.key == K_DOWN:
                                DDOWN = 0
                        if event.key == K_SPACE:
                                SBDOWN = 0
#end checkEvent

#start BG (Will give it a sprite later)
class BG():
    def _init_(self, posx,posy,width,height):
        self.pos = [posx,posy]
        self.dimensions = [width,height]
        self.blocks = [0] * 300
#end BG
   
#entire game initialization defined as 'reset'
def reset():
        pygame.mixer.stop()
        #globalize all changed variables
        global Trump, Screens
        Trump = Mario()
        Trump._init_(32,(480-64-64-64-64),32,64,"assets\sprites\player\donald-trump-side.png",1,3)
        Trump.inAir = 0
        Screens = [BG(),BG(),BG(),BG(),BG(),BG(),BG(),BG(),BG(),BG(),BG()]
        Flaggy = 0
        
        Blockbuild()
        overworld.play(loops=-1)
#end reset
        
#start Blockbuild
def Blockbuild():
    def Assemble(obj,layout):
        global Flaggy
        col = 0
        row = 0
        for i in range(300):
            if col > 19:
                col = 0
                row += 1
            if row > 14:
                row = 0
            if layout[i] == 1:
                obj.blocks[i] = Block()
                obj.blocks[i]._init_((obj.pos[0] + col*32),row*32,32,32,"assets/sprites/block/platform-top.png",1,1)
                obj.blocks[i].image.play()
            if layout[i] == 2:
                obj.blocks[i] = Block()
                obj.blocks[i]._init_((obj.pos[0] + col*32),row*32,32,32,"assets/sprites/block/question-block-new.png",2,1)
                obj.blocks[i].image.play()
            if layout[i] == 3:
                obj.blocks[i] = Block()
                obj.blocks[i]._init_((obj.pos[0] + col*32),row*32,32,32,"assets/sprites/block/brick1.png",3,1)
                obj.blocks[i].image.play()
            if layout[i] == 4:
                obj.blocks[i] = Block()
                obj.blocks[i]._init_((obj.pos[0] + col*32),row*32,32,32,"assets/sprites/block/pipe-base-1.png",1,1)
                obj.blocks[i].image.play()
            if layout[i] == 5:
                obj.blocks[i] = Block()
                obj.blocks[i]._init_((obj.pos[0] + col*32),row*32,32,32,"assets/sprites/block/pipe-base-2.png",1,1)
                obj.blocks[i].image.play()
            if layout[i] == 6:
                obj.blocks[i] = Block()
                obj.blocks[i]._init_((obj.pos[0] + col*32),row*32,32,32,"assets/sprites/block/pipe-top-1.png",1,1)
                obj.blocks[i].image.play()
            if layout[i] == 7:
                obj.blocks[i] = Block()
                obj.blocks[i]._init_((obj.pos[0] + col*32),row*32,32,32,"assets/sprites/block/pipe-top-2.png",1,1)
                obj.blocks[i].image.play()
            if layout[i] == 8:
                obj.blocks[i] = Block()
                obj.blocks[i]._init_((obj.pos[0] + col*32),row*32,32,32,"assets/sprites/block/platform-3.png",1,1)
                obj.blocks[i].image.play()
            if layout[i] == 9:
                global Flaggy
                Flaggy = Flagpole()
                Flaggy._init_((obj.pos[0] + col*32 + 8),row*32 + 16,16,304,"assets/sprites/bg/flagpole.png")
                Flaggy.image.play()
            col += 1
    global Screens
    for i in range(len(Screens)):
                Screens[i]._init_((i*640),0,640,480)
    j = 0
    Screens[j].blocks = [0] * 300
    blocklayout = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,3,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
    col = 0
    row = 0
    Assemble(Screens[j],blocklayout)
    j += 1
    Screens[j].blocks = [0] * 300
    blocklayout = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   2,3,2,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,7,0,
                   0,0,0,0,0,0,0,6,7,0,0,0,0,0,0,0,0,4,5,0,
                   0,0,0,0,0,0,0,4,5,0,0,0,0,0,0,0,0,4,5,0,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
    
    col = 0
    row = 0
    Assemble(Screens[j],blocklayout)
    j += 1
    Screens[j].blocks = [0] * 300
    blocklayout = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,6,7,0,0,0,0,0,0,0,0,0,6,7,0,0,
                   0,0,0,0,0,4,5,0,0,0,0,0,0,0,0,0,4,5,0,0,
                   0,0,0,0,0,4,5,0,0,0,0,0,0,0,0,0,4,5,0,0,
                   0,0,0,0,0,4,5,0,0,0,0,0,0,0,0,0,4,5,0,0,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
    col = 0
    row = 0
    Assemble(Screens[j],blocklayout)
    j += 1   
    Screens[j].blocks = [0] * 300
    blocklayout =[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,2,3,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,
                   1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1]
    col = 0
    row = 0
    Assemble(Screens[j],blocklayout)
    Screens[j].blocks = [0] * 300
    blocklayout =[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   3,3,3,3,3,3,3,0,0,0,3,3,3,2,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,3,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   1,1,1,1,1,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,
                   1,1,1,1,1,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1]
    col = 0
    row = 0
    Assemble(Screens[j],blocklayout)
    j += 1
    Screens[j].blocks = [0] * 300
    blocklayout =[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,3,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   2,0,0,0,0,2,0,0,2,0,0,2,0,0,0,0,3,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
    col = 0
    row = 0
    Assemble(Screens[j],blocklayout)
    j += 1
    Screens[j].blocks = [0] * 300
    blocklayout = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   3,3,0,0,0,0,0,3,2,2,3,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,3,3,0,0,0,0,0,8,0,0,8,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,8,0,0,8,8,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,8,8,8,0,0,8,8,
                   0,0,0,0,0,0,0,0,0,0,0,0,8,8,8,8,0,0,8,8,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
    col = 0
    row = 0
    Assemble(Screens[j],blocklayout)
    j += 1
    Screens[j].blocks = [0] * 300
    blocklayout = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,8,8,0,0,8,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,8,8,8,0,0,8,8,0,0,0,0,0,
                   8,0,0,0,0,0,0,8,8,8,8,0,0,8,8,8,0,0,0,0,
                   8,8,0,0,0,0,8,8,8,8,8,0,0,8,8,8,8,0,0,0,
                   1,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,
                   1,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1]
    col = 0
    row = 0
    Assemble(Screens[j],blocklayout)
    j += 1
    Screens[j].blocks = [0] * 300
    blocklayout =[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,3,3,2,3,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,6,7,0,0,0,0,0,0,0,0,0,0,0,0,0,6,7,0,8,
                   0,4,5,0,0,0,0,0,0,0,0,0,0,0,0,0,4,5,8,8,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
    col = 0
    row = 0
    Assemble(Screens[j],blocklayout)
    j += 1
    Screens[j].blocks = [0] * 300
    blocklayout = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,8,8,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,8,8,8,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,8,8,8,8,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,8,8,8,8,8,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,8,8,8,8,8,8,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   8,8,8,8,8,8,8,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   8,8,8,8,8,8,8,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   8,8,8,8,8,8,8,0,0,0,0,0,0,0,0,0,0,0,8,0,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
    col = 0
    row = 0
    Assemble(Screens[j],blocklayout)
    j += 1
    Screens[j].blocks = [0] * 300
    blocklayout = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
    col = 0
    row = 0
    Assemble(Screens[j],blocklayout)
#end Blockbuild

              
#start Sprite
class Sprite(object):
        def _init_(self,sx,sy,swidth,sheight,simage):
                self.pos = [sx, sy]
                self.image = pyganim.PygAnimation([(simage,1)])
                self.image.play()
                self.dimensions = [swidth,sheight]
                self.speed = [10,10]
                self.movement = ['none','none']
        #checkCollide function. Use like: if whatever.checkCollide(object): code here
        def checkCollide(self, obj):
                state = 0
                                
                selfbottom = self.pos[1] + self.dimensions[1]
                selfright = self.pos[0] + self.dimensions[0]
                selfleft = self.pos[0]
                selftop = self.pos[1]
                
                objbottom = obj.pos[1] + obj.dimensions[1]
                objright = obj.pos[0] + obj.dimensions[0]
                objleft = obj.pos[0]
                objtop = obj.pos[1]
                
                if selfright > objleft and selfbottom > objtop and selfleft < objright and selftop < objbottom:
                        state = 1
                return state
        
        def update(self):
                self.image.blit(setDisplay,(self.pos[0],self.pos[1]))
#end Sprite

#start Mario
class Mario(Sprite):
        def _init_(self,sx,sy,swidth,sheight,simage,stat,live):
                #x and y position
                self.pos = [sx, sy]
                #image dimensions and image animation
                self.dimensions = [swidth,sheight]
                self.image = pyganim.PygAnimation([(simage, 1)])
                self.image.play()
                #correct the imcompetant spawner by rounding his outrageous number to an appropriate value
                if stat > 4:
                        self.state = 4
                elif stat < 0:
                        self.state = 0
                else:
                        self.state = stat
                #amount of cash money collected (displayed in-game)
                self.coins = 0

                #lives
                self.lives = live
                
                #airborne or no?
                self.inAir = 0

                self.speed = 4

                #potential momentum in a specific direction
                self.delta = [0,0]

                self.liftAmt = 0

                self.jumping = 0

                self.shadow = Sprite()
                self.shadow._init_(sx,sy,64,128,"assets/sprites/player/donald-trump-side-glow.png")

                #VERY IMPORTANT outer shield for detecting if mario is on the floor or directly against a wall
                self.buffer = [Sprite(),Sprite(),Sprite(),Sprite()]
                #I give the buffers images to better see them
                self.buffer[0]._init_(self.pos[0] - 1,self.pos[1],1,self.dimensions[1],'assets\sprites\player/bufferL.png')
                self.buffer[1]._init_(self.pos[0] + self.dimensions[0],self.pos[1],1,self.dimensions[1],'assets\sprites\player/bufferR.png')
                self.buffer[2]._init_(self.pos[0],self.pos[1] -1,self.dimensions[0],1,'assets\sprites\player/bufferU.png')
                self.buffer[3]._init_(self.pos[0],self.pos[1] + self.dimensions[1],self.dimensions[0],1,'assets\sprites\player/bufferD.png')
                for i in range(len(self.buffer)):
                    self.buffer[i].image.play()
                
        def move(self):
                #give mario's momentum some rightness
                if RDOWN:
                        if self.delta[0] < 8:
                                self.delta[0] += self.speed
                                self.image = pyganim.PygAnimation([("assets\sprites\player\donald-trump-side.png", 1)])
                                self.image.play()
                                self.shadow.image = pyganim.PygAnimation([("assets\sprites\player\donald-trump-side-glow.png", 1)])
                                self.shadow.image.play()
                #subtract from rightness and give some leftness
                if LDOWN:
                        if self.delta[0] > -8:
                                self.delta[0] -= self.speed
                                self.image = pyganim.PygAnimation([("assets\sprites\player\donald-trump-side.png", 1)])
                                self.image.flip(1,0)
                                self.shadow.image = pyganim.PygAnimation([("assets\sprites\player\donald-trump-side-glow.png", 1)])
                                self.shadow.image.flip(1,0)
                                self.shadow.image.play()
                                self.image.play()
                #slow momentum down
                
                skid = self.speed/2
                if self.delta[0] < 0:
                    self.delta[0] += skid
                if self.delta[0] > 0:
                    self.delta[0] -= skid
                #apply speed to actual position
                self.pos[0] += self.delta[0]

        def jump(self):
                #if player is not on a platform, inAir is set to 1
                fall = 1
                for j in range(len(Screens)):
                    for i in range(len(Screens[j].blocks)):                    
                        if Screens[j].blocks[i] != 0:
                            if self.buffer[3].checkCollide(Screens[j].blocks[i]):
                                fall = 0
                        self.inAir = fall
                        if fall == 1 and self.delta[1] > 0:
                                self.liftAmt = 8
                    
                if self.pos[1] > 480:
                        self.state = 0
                #if in air, gravity happens
                if self.inAir:
                        self.delta[1] += 1
                        
                #if on ground, you're good
                if self.inAir == 0:
                        self.delta[1] = 0
                        self.liftAmt = 0
                        self.jumping = 0
                #if pressing space, jump momentum and in air
                if SBPRESS and self.inAir == 0:
                        self.inAir = 1
                        global SBPRESS
                        SBPRESS = 0
                        self.delta[1] = -4
                        winsound.PlaySound("assets/sounds/jump.wav", winsound.SND_ASYNC)
                        self.jumping = 1
                if SBPRESS:
                        global SBPRESS
                        SBPRESS = 0
                if SBDOWN and self.inAir and self.jumping:
                        if self.liftAmt < 8:
                                self.delta[1] -= 2
                                self.liftAmt += 1
                
                    
                #apply changes? |apply|/|ok|
                self.pos[1] += self.delta[1]
                
        def collide(self,obj,thing):
                #enemy collision
                if thing == 'enemy':
                        #if colliding with goomba that has not been killed,
                        if self.checkCollide(obj) and obj.type == 0 and obj.state != 0:
                                #if player's lower half is higher than goomba's head
                                if self.pos[1] + 24 < obj.y:
                                        #kill goomba and give jump boost
                                        self.kill(obj)
                                        self.delta[1] -= 25
                                #if player's lower half is lower than goomba's head, damage ensues
                                elif self.pos[1] + 24 > obj.y:
                                        self.state -= 1
                                        if self.state <= 0:
                                                self.die()
                        #if colliding with koopa,
                        elif self.checkCollide(obj) and obj.type >= 1:
                                #if lower half is higher, turn koopa into shell
                                if self.pos[1] + 24 < obj.y:
                                        obj.state = 1
                                        self.delta[1] -= 25
                                #otherwise, d-d-d-d-damage
                                else:
                                        self.state -= 1
                                        if self.state <= 0:
                                                self.die()
                
                #BLOCK COLLISION MY GOODNESS
                #O (amount of pixels away from block the player is before they collide * 4)
                if thing == 'block':
                        #if the player is colliding with a solid block
                        if self.checkCollide(obj) and obj.type < 4:
                            #rewind the position of the previous frame
                            self.pos[0] -= self.delta[0]
                            self.pos[1] -= self.delta[1]
                            if self.checkCollide(obj):
                                    self.pos[0] -= self.delta[0]
                                    self.pos[1] -= self.delta[1]
                            #align the buffer sprites with the player
                            self.buffer[0].pos = [self.pos[0] - 1, self.pos[1]]
                            self.buffer[1].pos = [self.pos[0] + self.dimensions[0], self.pos[1]]
                            self.buffer[2].pos = [self.pos[0],self.pos[1] - 1]
                            self.buffer[3].pos = [self.pos[0],self.pos[1] + self.dimensions[1]]
                            #set up the movement direction for correcting collision
                            
                            if self.delta[1] > 0: movey = 1
                            elif self.delta[1] < 0: movey = -1
                            else: movey = 0

                            if self.delta[0] > 0 :movex = 1
                            elif self.delta[0] < 0 :movex = -1
                            else: movex = 0
                            
                            
                            count = 0
                            state = 0
                            #while state is zero, continue these actions:
                            while state == 0:
                                #check whether any buffer has collided with the wall
                                for i in range(len(self.buffer)):
                                        if self.buffer[i].checkCollide(obj):
                                                #if horizontal buffer collides, cancel x speed and assume y buffers have not collided; y speed will continue
                                                if i == 0 or i == 1:
                                                        self.delta[0] = 0
                                                        #this line makes sure speed is re-added only once
                                                        if state == 0:
                                                                #y speed continues as it were
                                                                self.pos[1] += self.delta[1]
                                                        state = 1
                                                #if vertical buffer collides, cancel y speed and add delta x to x position, resuming the x motion. If x collision has already been triggered and delta x reset to 0, nothing will be added
                                                if i == 2 or i == 3:
                                                        self.delta[1] = 0
                                                        #this line makes sure speed is re-added only once
                                                        if state == 0:
                                                                self.pos[0] += self.delta[0]
                                                        state = 1
                                #if no collision, move player forward by 1 pixel on each axis and then realign the positions of the buffers
                                if state == 0:
                                        self.pos[0] += movex
                                        self.pos[1] += movey
                                        self.buffer[0].pos = [self.pos[0] - 1, self.pos[1]]
                                        self.buffer[1].pos = [self.pos[0] + self.dimensions[0], self.pos[1]]
                                        self.buffer[2].pos = [self.pos[0],self.pos[1] - 1]
                                        self.buffer[3].pos = [self.pos[0],self.pos[1] + self.dimensions[1]]
                                #sets player's inAir state to 0 if recovered from floor collision
                                if state == 1:
                                        if self.buffer[2].checkCollide(obj):
                                                bump.play()
                                                self.liftAmt = 8
                                                #winsound.PlaySound("assets/sounds/bump.wav", winsound.SND_ASYNC)
                                        if self.buffer[3].checkCollide(obj):
                                                self.inAir = 0
                                                self.liftAmt = 0
                                count += 1
                                if count == 100:
                                        state = 1
                #edges of screen barriers
                if self.pos[0] < 0: self.pos[0] = 0
                if self.pos[0] > 640-self.dimensions[0]: self.pos[0] = 640 - self.dimensions[0]
                            
                
        #end collide
                
        def die(self):
                self.lives -= 1
                if self.lives == -1:
                        global GAMEOVER
                        GAMEOVER = 1
                elif self.state == 0:
                        self.pos = [32,(480-128)]
                        self.inAir = 0
                        self.state = 1
                        self.coins = 0
                        self.delta[0] = 0
                        self.delta[1] = 0
                        Blockbuild()
                        winsound.PlaySound("assets/sounds/death.wav", winsound.SND_ALIAS)
                        self.liftAmt = 0
                        #reset enemies
        def kill(self,obj):
                obj.state = 0
                
        def update(self):
                  #disabled buffer textures
##                for i in range(len(self.buffer)):
##                    self.buffer[i].image.blit(setDisplay,(self.buffer[i].pos[0],self.buffer[i].pos[1]))
                self.shadow.image.blit(setDisplay,(self.pos[0] - (self.shadow.dimensions[0]/2) + (self.dimensions[0]/2),self.pos[1] - (self.shadow.dimensions[1]/2) + (self.dimensions[1]/2)))
                self.image.blit(setDisplay,(self.pos[0],self.pos[1]))
                
        def main(self):
                self.move()
                self.jump()

                #block collisions
                for j in range(len(Screens)):
                    for i in range(len(Screens[j].blocks)):
                                if self.delta[1] >= 0:
                                        if Screens[j].blocks[i] != 0:
                                                self.collide(Screens[j].blocks[i],"block")
                                elif self.delta[1] < 0:
                                        if Screens[j].blocks[299 - i] != 0:
                                                self.collide(Screens[j].blocks[299-i],"block")
                                        
                                
                                        
                            
                self.die()

                #buffer position reset
                self.buffer[0].pos = [self.pos[0] - 1, self.pos[1]]
                self.buffer[1].pos = [self.pos[0] + self.dimensions[0], self.pos[1]]
                self.buffer[2].pos = [self.pos[0],self.pos[1] - 1]
                self.buffer[3].pos = [self.pos[0],self.pos[1] + self.dimensions[1]]

                #if player is not on a platform, inAir is set to 1
                fall = 1
                for j in range(len(Screens)):
                    for i in range(len(Screens[j].blocks)):                    
                        if Screens[j].blocks[i] != 0:
                            if self.buffer[3].checkCollide(Screens[j].blocks[i]):
                                fall = 0
                        self.inAir = fall
                        if fall == 1 and self.delta[1] > 0:
                                self.liftAmt = 8
                
                
                #self.kill()    
#end Mario
                        
#start Enemy
class Enemy(Sprite):
        def _init_(self,sx,sy,swidth,sheight,simage,typ,stat):
                self.pos = [sx, sy]
                
                self.image = pyganim.PygAnimation([(simage)])
                self.dimensions = [swidth,sheight]
                
                self.speed = [10,10]
                
                self.type = typ
                self.state = stat
                self.inAir = 0
                self.direction = 'l'
                
                self.buffer = [Sprite(),Sprite(),Sprite(),Sprite()]
                self.buffer[0]._init_(self.pos[0] - 1,self.pos[1],1,32,'assets\sprites\player/bufferL.png')
                self.buffer[1]._init_(self.pos[0] + 16,self.pos[1],1,32,'assets\sprites\player/bufferR.png')
                self.buffer[2]._init_(self.pos[0],self.pos[1] -1,16,1,'assets\sprites\player/bufferU.png')
                self.buffer[3]._init_(self.pos[0],self.pos[1] +32,16,1,'assets\sprites\player/bufferD.png')

        def move(self):
                if self.direction == 'l':
                        self.pos[0] -= self.speed[0]
                else:
                        self.pos[0] += self.speed[0]
        def collide(self,wall):
                #may need retooling depending on if glitches occur
                if self.buffer[1].checkCollide(wall):
                        self.direction == "l"
                elif self.buffer[1].checkCollide(wall) == 0 and self.buffer[0].checkCollide(wall):
                        self.direction == "r"
                if self.buffer[3].checkCollide(wall) and self.inAir == 1:
                        self.pos[1] = wall.pos[1] - self.dimensions[1]
                        self.inAir = 0
        def die(self):
                if self.state == 0:
                        self.speed = [0,0]
                        self.pos = [0-self.dimensions[0],0-self.dimensions[1]]
        def main(self):
            self.move()
            #self.collide()
            self.die()
            self.update()
#end Enemy
#start Block
class Block(Sprite):
    def _init_(self,sx,sy,swidth,sheight,simage,typ,stat):
                self.pos = [sx, sy]
                
                self.image = pyganim.PygAnimation([(simage, 1)])
                self.dimensions = [swidth,sheight]
                
                self.speed = [10,10]
                
                self.type = typ

                if self.type == 2:
                        self.image = pyganim.PygAnimation([("assets/sprites/block/question-block-new.png", 0.5),
                                                           ("assets/sprites/block/question-block-new2.png", 0.2),
                                                           ("assets/sprites/block/question-block-new3.png", 0.2),
                                                           ("assets/sprites/block/question-block-new2.png", 0.2)])
                        self.image.play()
                elif self.type == 3:
                        self.image = pyganim.PygAnimation([("assets/sprites/block/brick1.png", 5),
                                                           ("assets/sprites/block/brick2.png", 0.1),
                                                           ("assets/sprites/block/brick3.png", 0.1),
                                                           ("assets/sprites/block/brick4.png", 0.1)])
                        self.image.play()
                
                self.state = stat
                self.inAir = 0
                self.direction = 'r'
                
                self.buffer = [Sprite(),Sprite(),Sprite(),Sprite()]
##                self.buffer[0]._init_(self.pos[0] - 1,self.pos[1],1,32,'assets\sprites\player/bufferL.png')
##                self.buffer[1]._init_(self.pos[0] + 16,self.pos[1],1,32,'assets\sprites\player/bufferR.png')
##                self.buffer[2]._init_(self.pos[0],self.pos[1] -1,16,1,'assets\sprites\player/bufferU.png')
##                self.buffer[3]._init_(self.pos[0],self.pos[1] +32,16,1,'assets\sprites\player/bufferD.png')

                self.spring = 0

    def move(self):
        if self.type > 3:
            hi = 1
            #code n'stuf 
    def collide(self):
        if self.type > 3:
            hi = 2
            #code n'stuf
    def morph(self,obj):
        if self.type > 3:
            hi = 3
            #code n'stuf
    def main(self):
        self.move()
        #self.collide()
        #self.morph()
        if self.pos[0] + self.dimensions[0] > 0 and self.pos[0] < 640:
            self.update()
#end Block

#start Flagpole
class Flagpole(Sprite):
    def _init_(self,sx,sy,swidth,sheight,simage):
        self.pos = [sx,sy]
        self.dimensions = [swidth,sheight]
        self.image = pyganim.PygAnimation([(simage,1)])
        self.image.play()
    def main(self,obj):
        if self.checkCollide(obj):
            global WIN
            WIN = 1
        self.update()
        








def scroll():
    if Trump.pos[0] > 320 and Trump.delta[0] > 0:
        for j in range(len(Screens)):
            for i in range(len(Screens[j].blocks)):            
                if Screens[j].blocks[i] != 0:
                    Screens[j].blocks[i].pos[0] -= Trump.delta[0]
        Flaggy.pos[0] -= Trump.delta[0]
        Trump.pos[0] = 320
        for i in range(len(Trump.buffer)):
                Trump.buffer[i].pos[0] -= Trump.delta[0]
    elif Trump.pos[0] > 320 and RDOWN:
        for j in range(len(Screens)):
            for i in range(len(Screens[j].blocks)):            
                if Screens[j].blocks[i] != 0:
                    Screens[j].blocks[i].pos[0] -= Trump.delta[0]
        Trump.pos[0] = 320
        for i in range(len(Trump.buffer)):
                Trump.buffer[i].pos[0] -= Trump.delta[0]
        
##    if Trump.pos[0] < 320 and Trump.delta[0] != 0 and LDOWN:
##        for j in range(len(Screens)):
##            for i in range(len(Screens[j].blocks)):
##                if Screens[j].blocks[i] != 0:
##                    Screens[j].blocks[i].pos[0] -= Trump.delta[0]
##        Trump.pos[0] -= Trump.delta[0]
##        for i in range(len(Trump.buffer)):
##                Trump.buffer[i].pos[0] -= Trump.delta[0]

        
reset()

#gameloop
while 1:
        setDisplay.fill((92,148,252))
        checkEvent()
        #handle frame-to-frame events here

        if WIN == 0:
                
                            
                Trump.main()
                
                scroll()
        else:
                global ENDTIMER
                Trump.delta[0] = 0
                Trump.delta[1] = 1
                if ENDTIMER == 0:
                        overworld.stop()
                        
                        Trump.pos[0] = Flaggy.pos[0] - Trump.dimensions[0]
                ENDTIMER += 1
##                if ENDTIMER == 20:
##                        
##                        Trump.image = pyganim.PygAnimation([("assets/sprites/player/Trump.png",1),("assets/sprites/player/donald-trump-side.png",1)])
##                        Trump.image.play()
                if ENDTIMER == 20:
                        winsound.PlaySound("assets/sounds/flag.wav", winsound.SND_ASYNC)
                if ENDTIMER > 20 and Trump.pos[0] + Trump.dimensions[1] < Flaggy.pos[0] + Flaggy.dimensions[1] - 3 and ENDTIMER > 0:
                        Trump.pos[1] += 3
                        
                if ENDTIMER > 20 and Trump.pos[1] + Trump.dimensions[1] > Flaggy.pos[1] + Flaggy.dimensions[1] - 3:
                        ENDTIMER = -100
                        Trump.pos[1] = Flaggy.pos[1] + Flaggy.dimensions[1] - Trump.dimensions[1] 
                if ENDTIMER == -100:
                        Trump.pos[0] = Flaggy.pos[0] + Flaggy.dimensions[0] - Trump.dimensions[0]
                        ending.play()
                if ENDTIMER > -50 and ENDTIMER < 0 and Trump.pos[0] < 480:
                        global RDOWN, SBDOWN, LDOWN
                        RDOWN = 1
                        LDOWN = 0
                        SBDOWN = 0
                        SBPRESS = 0
                        Trump.delta[0] = 8
                        Trump.main()
                if ENDTIMER == -1:
                        ENDTIMER = -2

        #draw blocks and other blocky functions
        for j in range(len(Screens)):
            for i in range(len(Screens[j].blocks)):
                if Screens[j].blocks[i] != 0:
                    Screens[j].blocks[i].main()
        Trump.update()
        Flaggy.main(Trump)
        pygame.display.update()
        fpsTime.tick(FPS)
quit
